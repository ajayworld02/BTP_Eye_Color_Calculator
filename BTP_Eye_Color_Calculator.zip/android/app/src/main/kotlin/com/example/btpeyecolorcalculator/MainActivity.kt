package com.example.btpeyecolorcalculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
